	$(document).ready(function(){
		$("body").ScrollToAnchors("slow");
		if($.browser.msie){
			if (navigator.appVersion < "7.0") {
				$("body.home #navigation li").hover(
					function(){
						$(this).add($(this).children("a")).addClass("jshover");
					},
					function(){
						$(this).add($(this).children("a")).removeClass("jshover");
					}
				);	
			}
		}
	});